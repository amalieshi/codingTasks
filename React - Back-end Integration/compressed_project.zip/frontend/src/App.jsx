import { useState, useEffect } from 'react';

import axios from 'axios';

import './App.css';

function App() {

  const [data, setData] = useState({}); // State to store fetched data

  useEffect(() => {

    fetchData(); // Fetch data each time the component loads

  }, []);

  const [customMessage, setCustomMessage] = useState('');

  // Function to fetch data from the server

  const fetchData = async () => {

    try {

      /* Sends a GET request to
      
      'http://localhost:5001/api/data' (backend server) */

      const response = await axios.get('/api/data');

      setData(response.data); // Update state with fetched data

    } catch (error) {

      console.error('Error fetching data:', error);

    }

  };

  useEffect(() => {
    const fetchMessage = async () => {
      try {
        const response = await axios.get('/api/message');
        setCustomMessage(response.data.message || 'writing my first message here');
      } catch (error) {
        console.error('Error fetching message:', error);
        setCustomMessage('writing my first message here');
      }
    };

    fetchMessage();
  }, []);
 
  
  return (
    <div className="App">
      <header className="App-header">
        <h1>{data.message || 'Loading...'}</h1>
        <h2>{customMessage || 'Loading custom message...'}</h2>
      </header>
    </div>
  );

 

}

export default App;